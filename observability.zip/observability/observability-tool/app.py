# app.py

from flask import Flask, request, jsonify
from prometheus_client import Counter, Gauge, Histogram, generate_latest

app = Flask(__name__)

# Define Prometheus metrics
REQUEST_COUNT = Counter('observability_request_count', 'Total number of requests')
LLM_LATENCY = Histogram('llm_response_latency_seconds', 'LLM response latency')
INPUT_DRIFT = Gauge('llm_input_drift', 'Input drift detected')
OUTPUT_DRIFT = Gauge('llm_output_drift', 'Output drift detected')
ACCURACY_SCORE = Gauge('llm_accuracy_score', 'Accuracy score of the response')
RELEVANCE_SCORE = Gauge('llm_relevance_score', 'Relevance score of the response')

@app.route('/log', methods=['POST'])
def log_data():
    data = request.json
    REQUEST_COUNT.inc()
    LLM_LATENCY.observe(data['response_time'])
    print("Received Data:", data)
    return jsonify({"status": "success"}), 200

@app.route('/log/drift', methods=['POST'])
def log_drift():
    data = request.json
    if data['input_drift']:
        INPUT_DRIFT.set(1)
    else:
        INPUT_DRIFT.set(0)
        
    if data['output_drift']:
        OUTPUT_DRIFT.set(1)
    else:
        OUTPUT_DRIFT.set(0)

    print("Received Drift Data:", data)
    return jsonify({"status": "success"}), 200

@app.route('/log/evaluation', methods=['POST'])
def log_evaluation():
    data = request.json
    ACCURACY_SCORE.set(data['accuracy_score'])
    RELEVANCE_SCORE.set(data['relevance_score'])
    print("Received Evaluation Data:", data)
    return jsonify({"status": "success"}), 200

@app.route('/metrics')
def metrics():
    return generate_latest(), 200

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001)
