import os
from flask import Flask, request, jsonify
from langchain.chat_models import ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain.schema import HumanMessage
import time
import requests
import numpy as np
from scipy.spatial.distance import jensenshannon

# Read OpenAI API Key from Environment Variable
openai_api_key = os.getenv("OPENAI_API_KEY")

# Initialize Chat LLM
chat_llm = ChatOpenAI(model_name="gpt-3.5-turbo", openai_api_key=openai_api_key)

# Define Chat Prompt Template
prompt_template = ChatPromptTemplate.from_template("What is the capital of {country}?")

# Define Observability Tool API Endpoint
OBSERVABILITY_API_URL = "http://observability-tool:5001/log"

# Initialize Flask app
app = Flask(__name__)

# Example of historical data (should be replaced with real historical data)
historical_input_data = {
    'num_tokens': 20,  # Example mean token count
    'token_length_distribution': [5, 10, 15, 20, 25]  # Example lengths
}

historical_output_data = {
    'num_tokens': 5,  # Example mean token count
    'token_length_distribution': [1, 1, 2, 2, 3]  # Example lengths
}

def create_token_length_bins(token_lengths, bin_size=5):
    """Create a histogram with bins for token lengths."""
    # Example binning: Group lengths by bin_size (e.g., lengths 1-5, 6-10, etc.)
    if not token_lengths:
        return [0] * ((5 // bin_size) + 1)
    
    max_length = int(max(token_lengths))  # Ensure max_length is an integer
    
    # Use integer division
    bins = [0] * ((max_length // bin_size) + 1)
    
    for length in token_lengths:
        bin_index = length // bin_size  # Ensure integer division
        bin_index = int(bin_index)  # Ensure bin_index is an integer
        bins[bin_index] += 1
    
    # Normalize the bins to create a distribution
    total = float(sum(bins))
    if total > 0:
        bins = [x / total for x in bins]
    
    return bins

def compute_jsd(current_distribution, reference_distribution):
    """Compute Jensen-Shannon Divergence between two distributions."""
    # Ensure inputs are numpy arrays for operations
    current = np.array(current_distribution, dtype=float)
    reference = np.array(reference_distribution, dtype=float)

    # Normalize distributions (should already be normalized, but ensure it)
    current_sum = np.sum(current)
    reference_sum = np.sum(reference)

    if current_sum > 0:
        current /= current_sum
    if reference_sum > 0:
        reference /= reference_sum

    return jensenshannon(current, reference)

def monitor_llm_input_output(prompt, response, response_time):
    input_metadata = {
        "num_tokens": len(prompt.split()),
        "num_sentences": len(prompt.split('.')),
        "token_length_distribution": [len(token) for token in prompt.split()]
    }
    output_metadata = {
        "num_tokens": len(response.split()),
        "num_sentences": len(response.split('.')),
        "token_length_distribution": [len(token) for token in response.split()]
    }

    data = {
        "component": "LLM",
        "input_metadata": input_metadata,
        "output_metadata": output_metadata,
        "response_time": response_time
    }

    response = requests.post(OBSERVABILITY_API_URL, json=data)
    print("Data sent:", response.status_code, response.text)

    return input_metadata, output_metadata

def drift_monitoring(input_metadata, output_metadata, historical_output_data):
    # Calculate token distribution and detect drift
    current_distribution = create_token_length_bins(output_metadata['token_length_distribution'])
    historical_distribution = create_token_length_bins(historical_output_data['token_length_distribution'])

    # Ensure both distributions have the same length by extending the shorter one
    max_length = max(len(current_distribution), len(historical_distribution))
    current_distribution.extend([0] * (max_length - len(current_distribution)))
    historical_distribution.extend([0] * (max_length - len(historical_distribution)))

    # Example JSD calculation
    jsd = compute_jsd(current_distribution, historical_distribution)

    print(f"Output Jensen-Shannon Divergence: {jsd}")

    # Calculate token count change ratio
    current_tokens = output_metadata['num_tokens']
    historical_tokens = historical_output_data['num_tokens']
    change_ratio = abs(current_tokens - historical_tokens) / historical_tokens

    print(f"Output Token Count Change Ratio: {change_ratio}")

    # Set thresholds for drift detection
    drift_threshold = 0.2  # Example threshold (20% change)
    jsd_threshold = 0.1  # Example JSD threshold

    output_drift = change_ratio > drift_threshold or jsd > jsd_threshold

    drift_data = {
        "output_drift": output_drift
    }

    requests.post(OBSERVABILITY_API_URL + "/drift", json=drift_data)

    if output_drift:
        print("Output Drift Detected")

    return output_drift

def evaluate_llm_response(response, ground_truth):
    accuracy_score = 1 if response.lower() == ground_truth.lower() else 0
    relevance_score = len(set(response.lower().split()) & set(ground_truth.lower().split())) / len(ground_truth.split())

    evaluation_data = {
        "accuracy_score": accuracy_score,
        "relevance_score": relevance_score
    }
    requests.post(OBSERVABILITY_API_URL + "/evaluation", json=evaluation_data)

    return accuracy_score, relevance_score

@app.route('/ask', methods=['POST'])
def ask():
    data = request.json
    country = data.get('country')

    if not country:
        return jsonify({'error': 'Country parameter is required'}), 400

    formatted_prompt = prompt_template.format(country=country)
    human_message = HumanMessage(content=formatted_prompt)

    start_time = time.time()
    response = chat_llm([human_message])
    response_time = time.time() - start_time

    response_content = response.content
    print(f"Country: {country}, Response: {response_content}")

    input_metadata, output_metadata = monitor_llm_input_output(formatted_prompt, response_content, response_time)

    drift_monitoring(input_metadata, output_metadata, historical_output_data)

    # Assuming you have a predefined ground truth for testing
    ground_truth = "Paris" if country.lower() == "france" else "Unknown"
    accuracy_score, relevance_score = evaluate_llm_response(response_content, ground_truth)

    return jsonify({
        'country': country,
        'response': response_content,
        'accuracy_score': accuracy_score,
        'relevance_score': relevance_score
    })

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8080)
