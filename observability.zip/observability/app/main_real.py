import os
from flask import Flask, request, jsonify
from langchain.chat_models import ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain.schema import HumanMessage
import time
import requests
import numpy as np
from scipy.spatial.distance import jensenshannon

# Import OpenTelemetry modules
from opentelemetry import trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.jaeger.thrift import JaegerExporter
from opentelemetry.instrumentation.flask import FlaskInstrumentor
from opentelemetry.instrumentation.requests import RequestsInstrumentor

# Set the service name
service_name = os.getenv("SERVICE_NAME", "llm_observability_service")

# Initialize OpenTelemetry tracer with the service name
trace.set_tracer_provider(
    TracerProvider(
        resource=Resource.create({"service.name": service_name})
    )
)

tracer = trace.get_tracer(__name__)

# Configure Jaeger exporter
jaeger_exporter = JaegerExporter(
    agent_host_name=os.getenv("JAEGER_AGENT_HOST", "localhost"),
    agent_port=6831,
)

# Add span processor to the tracer provider
trace.get_tracer_provider().add_span_processor(
    BatchSpanProcessor(jaeger_exporter)
)

# Read OpenAI API Key from Environment Variable
openai_api_key = os.getenv("OPENAI_API_KEY")

# Initialize Chat LLM
chat_llm = ChatOpenAI(model_name="gpt-3.5-turbo", openai_api_key=openai_api_key)

# Define Chat Prompt Template
prompt_template = ChatPromptTemplate.from_template("{question}")

# Define Observability Tool API Endpoint
OBSERVABILITY_API_URL = "http://observability-tool:5001/log"

# Initialize Flask app
app = Flask(__name__)

# Instrument Flask app with OpenTelemetry
FlaskInstrumentor().instrument_app(app)

# Instrument requests with OpenTelemetry
RequestsInstrumentor().instrument()

# Example of historical data (should be replaced with real historical data)
historical_input_data = {
    'num_tokens': 25,  # Example mean token count
    'token_length_distribution': [4, 5, 6, 7, 8]  # Example lengths
}

historical_output_data = {
    'num_tokens': 8,  # Example mean token count
    'token_length_distribution': [2, 3, 2, 1]  # Example lengths
}

def create_token_length_bins(token_lengths, bin_size=5):
    """Create a histogram with bins for token lengths."""
    # Example binning: Group lengths by bin_size (e.g., lengths 1-5, 6-10, etc.)
    if not token_lengths:
        return [0] * ((5 // bin_size) + 1)
    
    max_length = int(max(token_lengths))  # Ensure max_length is an integer
    
    # Use integer division
    bins = [0] * ((max_length // bin_size) + 1)
    
    for length in token_lengths:
        bin_index = length // bin_size  # Ensure integer division
        bin_index = int(bin_index)  # Ensure bin_index is an integer
        bins[bin_index] += 1
    
    # Normalize the bins to create a distribution
    total = float(sum(bins))
    if total > 0:
        bins = [x / total for x in bins]
    
    return bins

def compute_jsd(current_distribution, reference_distribution):
    """Compute Jensen-Shannon Divergence between two distributions."""
    # Ensure inputs are numpy arrays for operations
    current = np.array(current_distribution, dtype=float)
    reference = np.array(reference_distribution, dtype=float)

    # Normalize distributions (should already be normalized, but ensure it)
    current_sum = np.sum(current)
    reference_sum = np.sum(reference)

    if current_sum > 0:
        current /= current_sum
    if reference_sum > 0:
        reference /= reference_sum

    return jensenshannon(current, reference)

def monitor_llm_input_output(prompt, response, response_time):
    input_metadata = {
        "num_tokens": len(prompt.split()),
        "num_sentences": len(prompt.split('.')),
        "token_length_distribution": [len(token) for token in prompt.split()]
    }
    output_metadata = {
        "num_tokens": len(response.split()),
        "num_sentences": len(response.split('.')),
        "token_length_distribution": [len(token) for token in response.split()]
    }

    data = {
        "component": "LLM",
        "input_metadata": input_metadata,
        "output_metadata": output_metadata,
        "response_time": response_time
    }

    response = requests.post(OBSERVABILITY_API_URL, json=data)
    print("Data sent:", response.status_code, response.text)

    return input_metadata, output_metadata

def drift_monitoring(input_metadata, output_metadata, historical_input_data, historical_output_data):
    # Input drift detection
    current_input_distribution = create_token_length_bins(input_metadata['token_length_distribution'])
    historical_input_distribution = create_token_length_bins(historical_input_data['token_length_distribution'])

    # Ensure both distributions have the same length by extending the shorter one
    max_length_input = max(len(current_input_distribution), len(historical_input_distribution))
    current_input_distribution.extend([0] * (max_length_input - len(current_input_distribution)))
    historical_input_distribution.extend([0] * (max_length_input - len(historical_input_distribution)))

    # Input JSD calculation
    input_jsd = compute_jsd(current_input_distribution, historical_input_distribution)

    print(f"Input Jensen-Shannon Divergence: {input_jsd}")

    # Calculate input token count change ratio
    current_input_tokens = input_metadata['num_tokens']
    historical_input_tokens = historical_input_data['num_tokens']
    input_change_ratio = abs(current_input_tokens - historical_input_tokens) / historical_input_tokens

    print(f"Input Token Count Change Ratio: {input_change_ratio}")

    # Output drift detection
    current_output_distribution = create_token_length_bins(output_metadata['token_length_distribution'])
    historical_output_distribution = create_token_length_bins(historical_output_data['token_length_distribution'])

    # Ensure both distributions have the same length by extending the shorter one
    max_length_output = max(len(current_output_distribution), len(historical_output_distribution))
    current_output_distribution.extend([0] * (max_length_output - len(current_output_distribution)))
    historical_output_distribution.extend([0] * (max_length_output - len(historical_output_distribution)))

    # Output JSD calculation
    output_jsd = compute_jsd(current_output_distribution, historical_output_distribution)

    print(f"Output Jensen-Shannon Divergence: {output_jsd}")

    # Calculate output token count change ratio
    current_output_tokens = output_metadata['num_tokens']
    historical_output_tokens = historical_output_data['num_tokens']
    output_change_ratio = abs(current_output_tokens - historical_output_tokens) / historical_output_tokens

    print(f"Output Token Count Change Ratio: {output_change_ratio}")

    # Set thresholds for drift detection
    drift_threshold = 0.2  # Example threshold (20% change)
    jsd_threshold = 0.1  # Example JSD threshold

    input_drift = input_change_ratio > drift_threshold or input_jsd > jsd_threshold
    output_drift = output_change_ratio > drift_threshold or output_jsd > jsd_threshold

    drift_data = {
        "input_drift": input_drift,
        "output_drift": output_drift
    }

    requests.post(OBSERVABILITY_API_URL + "/drift", json=drift_data)

    if input_drift:
        print("Input Drift Detected")
    if output_drift:
        print("Output Drift Detected")

    return input_drift, output_drift

def evaluate_llm_response(response, ground_truth):
    accuracy_score = 1 if response.lower() == ground_truth.lower() else 0
    relevance_score = len(set(response.lower().split()) & set(ground_truth.lower().split())) / len(ground_truth.split())

    evaluation_data = {
        "accuracy_score": accuracy_score,
        "relevance_score": relevance_score
    }
    requests.post(OBSERVABILITY_API_URL + "/evaluation", json=evaluation_data)

    return accuracy_score, relevance_score

@app.route('/ask', methods=['POST'])
def ask():
    data = request.json
    question = data.get('question')

    if not question:
        return jsonify({'error': 'Question parameter is required'}), 400

    formatted_prompt = prompt_template.format(question=question)
    human_message = HumanMessage(content=formatted_prompt)

    # Start tracing this request
    with tracer.start_as_current_span("ask-span"):
        start_time = time.time()
        response = chat_llm([human_message])
        response_time = time.time() - start_time

        response_content = response.content
        print(f"Question: {question}, Response: {response_content}")

        input_metadata, output_metadata = monitor_llm_input_output(formatted_prompt, response_content, response_time)

        drift_monitoring(input_metadata, output_metadata, historical_input_data, historical_output_data)

        # Predefined ground truth for testing
        predefined_answers = {
            "What is the capital of France?": "Paris",
            "Who wrote 'To Kill a Mockingbird'?": "Harper Lee",
            "What is the largest planet in our solar system?": "Jupiter",
            "Who is the current President of the United States?": "Joe Biden",
            "What is the boiling point of water?": "100 degrees Celsius"
        }

        ground_truth = predefined_answers.get(question, "Unknown")
        accuracy_score, relevance_score = evaluate_llm_response(response_content, ground_truth)

    return jsonify({
        'question': question,
        'response': response_content,
        'accuracy_score': accuracy_score,
        'relevance_score': relevance_score
    })

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8080)
